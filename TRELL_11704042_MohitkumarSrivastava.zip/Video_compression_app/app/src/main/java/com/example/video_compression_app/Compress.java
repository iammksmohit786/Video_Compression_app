package com.example.video_compression_app;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.MediaController;
import android.widget.Toast;
import android.widget.VideoView;

public class Compress extends AppCompatActivity {
    private static final int SELECT_VIDEO = 1;
    Uri mVideoURI;
    EditText bitrate;
    VideoView videoView;
    ProgressDialog pd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_compress);
        videoView = findViewById(R.id.myvid);
        bitrate = findViewById(R.id.birate);
        pd = new ProgressDialog(Compress.this);
        pd.setMessage("Compressing Video");
                Intent intent = new Intent();
                intent.setType("video/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent, "Select Video"), SELECT_VIDEO);
    }
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode != RESULT_OK) return;

        if (requestCode == SELECT_VIDEO) {
             mVideoURI = data.getData();
            videoView.setVideoURI(mVideoURI);

            MediaController mediaController = new MediaController(this);
            mediaController.setAnchorView(videoView);
            videoView.setMediaController(mediaController);

            videoView.start();

        }
    }

    public void gotoMain(View view) {
        if (!bitrate.getText().toString().isEmpty()) {
            pd.show();
            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    Intent intent = new Intent(Compress.this, MainVideo.class);
                    intent.putExtra("VideoUri", mVideoURI.toString());
                    startActivity(intent);

                }
            }, 10000);
        }
        else{
            Toast.makeText(this, "Enter Bitrate Please", Toast.LENGTH_SHORT).show();
        }
    }
}
